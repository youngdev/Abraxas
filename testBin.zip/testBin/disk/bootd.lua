local core = luajava.getCore()
local windowManager = core:getRootManager()
local screen2 = core:getManager(0)
local fileOut = core:openPrintStream("test.txt", true)
local fileIn = core:openScanner("test.txt")
local prop = core:openProperties("test.txt")
local lang = core:openLang("en_US")
function boot()
core:getScreen(1):drawImage(core:generatePattern(core:getResource("Pattern_Cube"), core:rootWidth(), core:rootHeight()), 0, 0, core:rootWidth(), core:rootHeight(), core:getObserver())
core:getScreen(1):drawImage(core:generateBorder(core:createColor(0,0,0,255), core:rootWidth(), core:rootHeight(), 10), 0, 0, core:rootWidth(), core:rootHeight(), core:getObserver())
windowManager:addWindow(core:rootWidth()/2-250,core:rootHeight()/2-100,500,200,lang:getKey("BootTitle"))
windowManager:windowSurface(lang:getKey("BootTitle")):setColor(core:createColor(255,255,255,255))
windowManager:windowSurface(lang:getKey("BootTitle")):drawImage(core:vertGradient(core:createColor(95,1,1,255), core:createColor(181,10,10,255), 500, 200), 0,20,500,180, core:getObserver())
windowManager:windowSurface(lang:getKey("BootTitle")):drawString(lang:getKey("BootText"),5,35)
windowManager:windowSurface(lang:getKey("BootTitle")):drawString(lang:getKey("BootWait"),5,192)

screen2:addWindow(50,50,500,200,"WINDOWTITLE")
screen2:getWindow("WINDOWTITLE"):updateColors(core:createColor(0,0,0,255), core:createColor(0,0,255,255), core:createColor(0,0,0,255))
screen2:windowSurface("WINDOWTITLE"):drawImage(core:vertGradient(core:createColor(0,0,255,255), core:createColor(0,0,0,255), 500, 200), 0,20,500,180, core:getObserver())

windowManager:getWindow(lang:getKey("BootTitle")):addMouseRegion("INTERNALDRAG", "", 0,0,500,20)
windowManager:getWindow(lang:getKey("BootTitle")):addTextBox("TEST", 5, 160, 200, 16, "")

windowManager:getWindow(lang:getKey("BootTitle")):addTextBox("HARPDARP", 5, 144, 200, 16, "killRate")

windowManager:getWindow(lang:getKey("BootTitle")):textbox("HARPDARP"):setColors(core:createColor(0,0,0), core:createColor(0,0,255), core:createColor(255,255,255))
--This DESTROYS FRAMERATE!
--windowManager:getWindow(lang:getKey("BootTitle")):enableUpdates(true)

screen2:repaint()

while(true) do
core:getRoot():clearRect(0,0,100,100)
core:getRoot():drawString(core:getFPS(), 0, 20)
core:sleep(50)
--core:repaintScreen(0)
end
end
function allocate()

end
function postRender(window)
--Normally, this would draw things like the close and minimize boxes
end
function killRate()
windowManager:getWindow(lang:getKey("BootTitle")):enableUpdates(true)
end